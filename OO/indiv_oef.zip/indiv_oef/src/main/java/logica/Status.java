package logica;

public enum Status {
    OPEN,
    GESLOTEN
}
